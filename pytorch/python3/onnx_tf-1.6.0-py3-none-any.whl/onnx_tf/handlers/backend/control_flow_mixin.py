from .broadcast_mixin import BroadcastMixin


class LogicalMixin(BroadcastMixin):
  pass


class ComparisonMixin(BroadcastMixin):
  pass
